import os
from dotenv import load_dotenv

load_dotenv()

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if not DISCORD_TOKEN:
    raise ValueError("DISCORD_TOKEN não encontrado no arquivo .env")
if not GEMINI_API_KEY:
    raise ValueError("GEMINI_API_KEY não encontrado no arquivo .env")