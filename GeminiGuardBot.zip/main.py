import discord
import google.generativeai as genai
import config
import asyncio

# --- Configuração do Bot Discord ---
# Intents necessários para o bot ler mensagens, etc.
intents = discord.Intents.default()
intents.message_content = True  # Necessário para acessar o conteúdo das mensagens
intents.members = True # Necessário para funções de moderação (opcional, mas bom ter)

# Criação do cliente Discord
bot = discord.Client(intents=intents)

# --- Configuração do Gemini AI ---
genai.configure(api_key=config.GEMINI_API_KEY)
model = genai.GenerativeModel('gemini-pro')

# --- Funções Auxiliares ---
async def analyze_message_with_gemini(message_content: str) -> dict:
    """
    Analisa o conteúdo da mensagem usando o Gemini AI para fins de moderação.
    Retorna um dicionário com 'decision' (APROVADO/REPROVADO) e 'reason' (justificativa).
    """
    prompt = (
        "Analise a seguinte mensagem para conteúdo inapropriado, como discurso de ódio, assédio, spam, "
        "conteúdo sexualmente explícito, violência ou outros temas proibidos. "
        "Responda EXATAMENTE no formato: `DECISAO: [APROVADO|REPROVADO]` e na próxima linha `MOTIVO: [justificativa ou 'Nenhum']`."
        "\n\nMensagem: " + message_content
    )
    
    try:
        response = await asyncio.to_thread(model.generate_content, prompt)
        text_response = response.text.strip()
        
        decision = "APROVADO"
        reason = "Nenhum"

        lines = text_response.split('\n')
        for line in lines:
            if line.startswith("DECISAO:"):
                decision = line.split(":", 1)[1].strip().upper()
            elif line.startswith("MOTIVO:"):
                reason = line.split(":", 1)[1].strip()
        
        return {"decision": decision, "reason": reason}
    except Exception as e:
        print(f"Erro ao interagir com Gemini API: {e}")
        return {"decision": "ERRO", "reason": f"Falha na análise: {e}"}

async def query_gemini_directly(query: str) -> str:
    """
    Envia uma consulta direta ao Gemini AI e retorna a resposta.
    """
    try:
        response = await asyncio.to_thread(model.generate_content, query)
        return response.text.strip()
    except Exception as e:
        return f"Erro ao interagir com Gemini API: {e}"

# --- Eventos do Bot Discord ---
@bot.event
async def on_ready():
    """
    Executado quando o bot está online e conectado ao Discord.
    """
    print(f'Bot conectado como {bot.user}')
    print(f'Pronto para moderar e interagir!')
    # Você pode definir o status do bot aqui, por exemplo:
    # await bot.change_presence(activity=discord.Game(name="Moderando com IA"))

@bot.event
async def on_message(message: discord.Message):
    """
    Executado toda vez que uma mensagem é enviada em um canal que o bot pode ver.
    """
    # Ignorar mensagens do próprio bot para evitar loops infinitos
    if message.author == bot.user:
        return

    # --- Comando !askgemini ---
    if message.content.startswith('!askgemini '):
        query = message.content[len('!askgemini '):].strip()
        if not query:
            await message.channel.send("Por favor, forneça uma pergunta para o Gemini AI. Ex: `!askgemini Qual a capital da França?`")
            return
        
        await message.channel.send("Consultando Gemini AI... Por favor, aguarde.")
        response = await query_gemini_directly(query)
        
        # Limita o tamanho da resposta para evitar ultrapassar o limite do Discord
        if len(response) > 2000:
            response = response[:1990] + "..." # Trunca e adiciona reticências
        
        await message.channel.send(f"**Resposta do Gemini:**\n{response}")
        return # Não processar a mensagem como moderação se for um comando

    # --- Moderação de Mensagens com Gemini ---
    if message.guild: # Apenas para mensagens em servidores (não DM)
        print(f"Analisando mensagem de {message.author} no canal #{message.channel.name}: {message.content}")
        analysis = await analyze_message_with_gemini(message.content)
        
        if analysis["decision"] == "REPROVADO":
            try:
                # Tenta deletar a mensagem
                await message.delete()
                print(f"Mensagem de {message.author} deletada por: {analysis['reason']}")
                
                # Envia um aviso ao usuário (pode ser em DM ou no canal, aqui no canal)
                await message.channel.send(
                    f"{message.author.mention}, sua mensagem foi removida porque: **{analysis['reason']}**\n"
                    "Por favor, revise as regras do servidor."
                )
                # Você pode adicionar um sistema de log para um canal de moderação aqui
                mod_log_channel_id = 0 # Substitua pelo ID do canal de log de moderação
                if mod_log_channel_id:
                    mod_channel = bot.get_channel(mod_log_channel_id)
                    if mod_channel:
                        await mod_channel.send(
                            f"**Mensagem Removida:**\n"
                            f"**Usuário:** {message.author.display_name} ({message.author.id})\n"
                            f"**Canal:** {message.channel.name} ({message.channel.id})\n"
                            f"**Conteúdo Original:** `{message.content}`\n"
                            f"**Motivo Gemini:** {analysis['reason']}"
                        )

            except discord.Forbidden:
                print(f"Não tenho permissão para deletar mensagens no canal {message.channel.name}.")
                await message.channel.send(
                    f"Atenção: A mensagem de {message.author.mention} foi sinalizada como inadequada, "
                    f"mas não tenho permissão para removê-la. Motivo: {analysis['reason']}"
                )
            except Exception as e:
                print(f"Erro ao deletar mensagem: {e}")
                await message.channel.send(f"Ocorreu um erro ao tentar moderar a mensagem de {message.author.mention}.")
        else:
            print(f"Mensagem de {message.author} aprovada pelo Gemini.")

# --- Execução do Bot ---
if __name__ == '__main__':
    # Certifique-se de que o token do Discord esteja disponível
    if not config.DISCORD_TOKEN:
        print("Erro: O token do Discord não foi encontrado. Certifique-se de configurar o arquivo .env.")
    else:
        bot.run(config.DISCORD_TOKEN)